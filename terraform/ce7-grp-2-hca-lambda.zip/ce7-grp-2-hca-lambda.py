import boto3
import json
from decimal import Decimal

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('ce7-grp-2-hca-db')   

def lambda_handler(event, context):
    http_method = event['httpMethod']
    if http_method == "GET":
        return get_hca(event)
    else:
        return {
            "statusCode": 405,
            "body": json.dumps({"error": "Method not allowed"})
        }

def custom_serializer(obj):
    """Custom JSON serializer for DynamoDB Decimal objects."""
    if isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

def get_hca(event):
    response = table.scan()
    return {
        "statusCode": 200,
        "body": json.dumps(response['Items'], default=custom_serializer)
    }
