import boto3
import json
from datetime import datetime
from decimal import Decimal

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('ce7-grp-2-jokes-db-v2')   

def lambda_handler(event, context):
    http_method = event['httpMethod']
    if http_method == "GET":
        return get_jokes(event)
    elif http_method == "POST":
        return add_joke(event)
    elif http_method == "PUT":
        return update_joke(event)
    elif http_method == "DELETE":
        return delete_joke(event)
    else:
        return {
            "statusCode": 405,
            "body": json.dumps({"error": "Method not allowed"})
        }

def custom_serializer(obj):
    """Custom JSON serializer for DynamoDB Decimal objects."""
    if isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

def get_jokes(event):
    response = table.scan()
    return {
        "statusCode": 200,
        "body": json.dumps(response['Items'], default=custom_serializer)
    }

def add_joke(event):
    body = json.loads(event['body'])
    item = {
        "Id": int(body["Id"]),
        "Jokes": body["Jokes"],
        "DateCreation": datetime.utcnow().isoformat(),
        "TotalLikes": int(body.get("TotalLikes", 0))
    }
    table.put_item(Item=item)
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Joke added successfully"})
    }

def update_joke(event):
    body = json.loads(event['body'])
    table.update_item(
        Key={"Id": int(body["Id"])},
        UpdateExpression="SET Jokes = :j, TotalLikes = :t",
        ExpressionAttributeValues={
            ":j": body["Jokes"],
            ":t": int(body["TotalLikes"])
        }
    )
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Joke updated successfully"})
    }

def delete_joke(event):
    body = json.loads(event['body'])
    table.delete_item(Key={"Id": int(body["Id"])})
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Joke deleted successfully"})
    }
